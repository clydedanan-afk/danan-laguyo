﻿document.addEventListener('DOMContentLoaded', function () {
    const toastEl = document.getElementById('cartToast');
    if (toastEl && typeof bootstrap !== 'undefined') {
        const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
        toast.show();
    }
});
