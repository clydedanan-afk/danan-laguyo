using ecommerce_pastry.Models;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Diagnostics;

namespace ecommerce_pastry.Controllers
{
    public class HomeController : Controller
    {
        private const string CartSessionKey = "CartItems";
        private const string OrderHistorySessionKey = "OrderHistory";
        private static readonly List<Product> pastries = new()
        {
            new Product { Name = "Biscoff Bar", Price = 120, ImageUrl = "/images/pastries/biscoff-bar.png" },
            new Product { Name = "Classic Chocolate Chip Cookie", Price = 85, ImageUrl = "/images/pastries/classic-chocolate-chip-cookie.png" },
            new Product { Name = "Smores Cookie", Price = 95, ImageUrl = "/images/pastries/smores-cookie.png" },
            new Product { Name = "Triple Cheese Ensaymada", Price = 150, ImageUrl = "/images/pastries/triple-cheese-ensaymada.png" },
            new Product { Name = "Classic Ensaymada", Price = 120, ImageUrl = "/images/pastries/classic-ensaymada.png" },
            new Product { Name = "Choco Banana Bread", Price = 180, ImageUrl = "/images/pastries/choco-banana-bread.png" },
            new Product { Name = "Cheese Bread", Price = 70, ImageUrl = "/images/pastries/cheese-bread.png" },
            new Product { Name = "Brownie Fudge", Price = 110, ImageUrl = "/images/pastries/brownie-fudge.png" },
            new Product { Name = "Revel Bar", Price = 90, ImageUrl = "/images/pastries/revel-bar.png" },
            new Product { Name = "Cheese Roll", Price = 75, ImageUrl = "/images/pastries/cheese-roll.png" },
            new Product { Name = "Chiffon Cake", Price = 250, ImageUrl = "/images/pastries/chiffon-cake.png" },
            new Product { Name = "Choco Banana Muffin", Price = 80, ImageUrl = "/images/pastries/choco-banana-muffin.png" },
            new Product { Name = "Lava Cake", Price = 160, ImageUrl = "/images/pastries/lava-cake.png" },
            new Product { Name = "Oatmeal Cookie", Price = 85, ImageUrl = "/images/pastries/oatmeal-cookie.png" }
        };

        public IActionResult Index(string? search, string sort = "default")
        {
            var results = pastries.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                results = results.Where(p => p.Name.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            results = sort switch
            {
                "price-asc" => results.OrderBy(p => p.Price),
                "price-desc" => results.OrderByDescending(p => p.Price),
                _ => results
            };

            var model = new CatalogViewModel
            {
                Search = search ?? string.Empty,
                Sort = sort,
                Products = results.ToList()
            };

            return View(model);
        }

        public IActionResult AddToCart(string name, int price)
        {
            var cart = GetCartItems();
            var pastry = pastries.FirstOrDefault(p => p.Name == name && p.Price == price);
            var imageUrl = pastry?.ImageUrl ?? "/images/pastries/classic-chocolate-chip-cookie.png";

            var existingItem = cart.FirstOrDefault(item => item.Name == name && item.Price == price);
            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                cart.Add(new Product
                {
                    Name = name,
                    Price = price,
                    ImageUrl = imageUrl,
                    Quantity = 1
                });
            }

            SaveCartItems(cart);

            TempData["ToastMessage"] = $"{name} added to cart!";

            return RedirectToAction("Index");
        }

        public IActionResult Cart()
        {
            return View(GetCartItems());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult IncreaseQuantity(int index)
        {
            var cart = GetCartItems();

            if (index >= 0 && index < cart.Count)
            {
                cart[index].Quantity++;
                SaveCartItems(cart);
            }

            return RedirectToAction(nameof(Cart));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DecreaseQuantity(int index)
        {
            var cart = GetCartItems();

            if (index >= 0 && index < cart.Count)
            {
                cart[index].Quantity--;

                if (cart[index].Quantity <= 0)
                {
                    cart.RemoveAt(index);
                }

                SaveCartItems(cart);
            }

            return RedirectToAction(nameof(Cart));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RemoveFromCart(int index)
        {
            var cart = GetCartItems();

            if (index >= 0 && index < cart.Count)
            {
                cart.RemoveAt(index);
                SaveCartItems(cart);
            }

            return RedirectToAction(nameof(Cart));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ClearCart()
        {
            SaveCartItems(new List<Product>());
            return RedirectToAction(nameof(Cart));
        }

        [HttpGet]
        public IActionResult Checkout()
        {
            var cartItems = GetCartItems();
            if (cartItems.Count == 0)
            {
                return RedirectToAction(nameof(Cart));
            }

            var model = new CheckoutViewModel
            {
                CartItems = cartItems
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Checkout(CheckoutViewModel model)
        {
            var cartItems = GetCartItems();
            if (cartItems.Count == 0)
            {
                return RedirectToAction(nameof(Cart));
            }

            model.CartItems = cartItems;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var successModel = new CheckoutSuccessViewModel
            {
                OrderNumber = $"PP-{DateTime.UtcNow:yyyyMMddHHmmss}",
                OrderedAt = DateTime.Now,
                FullName = model.FullName,
                TotalAmount = cartItems.Sum(item => item.Price * item.Quantity)
            };

            SaveOrderHistoryItem(new OrderHistoryItem
            {
                OrderNumber = successModel.OrderNumber,
                OrderedAt = successModel.OrderedAt,
                FullName = successModel.FullName,
                PhoneNumber = model.PhoneNumber,
                Address = model.Address,
                TotalAmount = successModel.TotalAmount,
                TotalItems = cartItems.Sum(item => item.Quantity),
                Items = cartItems.Select(item => new Product
                {
                    Name = item.Name,
                    Price = item.Price,
                    ImageUrl = item.ImageUrl,
                    Quantity = item.Quantity
                }).ToList()
            });

            SaveCartItems(new List<Product>());

            return View("CheckoutSuccess", successModel);
        }

        public IActionResult Orders()
        {
            return View(GetOrderHistoryItems());
        }

        public IActionResult OrderDetails(string orderNumber)
        {
            var order = GetOrderHistoryItems().FirstOrDefault(o => o.OrderNumber == orderNumber);
            if (order == null)
            {
                return RedirectToAction(nameof(Orders));
            }

            order.Items ??= new List<Product>();

            return View(order);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private List<Product> GetCartItems()
        {
            var cartJson = HttpContext.Session.GetString(CartSessionKey);
            if (string.IsNullOrEmpty(cartJson))
            {
                return new List<Product>();
            }

            var cartItems = JsonSerializer.Deserialize<List<Product>>(cartJson) ?? new List<Product>();
            foreach (var item in cartItems.Where(item => item.Quantity <= 0))
            {
                item.Quantity = 1;
            }

            return cartItems;
        }

        private void SaveCartItems(List<Product> cartItems)
        {
            HttpContext.Session.SetString(CartSessionKey, JsonSerializer.Serialize(cartItems));
        }

        private List<OrderHistoryItem> GetOrderHistoryItems()
        {
            var historyJson = HttpContext.Session.GetString(OrderHistorySessionKey);
            if (string.IsNullOrEmpty(historyJson))
            {
                return new List<OrderHistoryItem>();
            }

            return JsonSerializer.Deserialize<List<OrderHistoryItem>>(historyJson) ?? new List<OrderHistoryItem>();
        }

        private void SaveOrderHistoryItem(OrderHistoryItem order)
        {
            var history = GetOrderHistoryItems();
            history.Insert(0, order);

            if (history.Count > 5)
            {
                history = history.Take(5).ToList();
            }

            HttpContext.Session.SetString(OrderHistorySessionKey, JsonSerializer.Serialize(history));
        }
    }
}
