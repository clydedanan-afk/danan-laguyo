namespace ecommerce_pastry.Models
{
    public class CatalogViewModel
    {
        public string Search { get; set; } = string.Empty;

        public string Sort { get; set; } = "default";

        public List<Product> Products { get; set; } = new();
    }
}
