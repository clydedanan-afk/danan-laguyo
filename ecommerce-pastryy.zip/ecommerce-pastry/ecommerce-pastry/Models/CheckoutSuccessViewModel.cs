namespace ecommerce_pastry.Models
{
    public class CheckoutSuccessViewModel
    {
        public string OrderNumber { get; set; } = string.Empty;

        public DateTime OrderedAt { get; set; }

        public string FullName { get; set; } = string.Empty;

        public int TotalAmount { get; set; }
    }
}
