﻿namespace ecommerce_pastry.Models
{
    public class Product
    {
        public string Name { get; set; } = string.Empty;

        public int Price { get; set; }

        public string ImageUrl { get; set; } = string.Empty;

        public int Quantity { get; set; } = 1;
    }
}