namespace ecommerce_pastry.Models
{
    public class OrderHistoryItem
    {
        public string OrderNumber { get; set; } = string.Empty;

        public DateTime OrderedAt { get; set; }

        public string FullName { get; set; } = string.Empty;

        public string PhoneNumber { get; set; } = string.Empty;

        public string Address { get; set; } = string.Empty;

        public int TotalAmount { get; set; }

        public int TotalItems { get; set; }

        public List<Product> Items { get; set; } = new();
    }
}
