namespace ecommerce_pastry.Models
{
    public class EmptyStateViewModel
    {
        public string Icon { get; set; } = "🍰";

        public string Title { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;

        public string? ButtonText { get; set; }

        public string? ButtonController { get; set; }

        public string? ButtonAction { get; set; }
    }
}
