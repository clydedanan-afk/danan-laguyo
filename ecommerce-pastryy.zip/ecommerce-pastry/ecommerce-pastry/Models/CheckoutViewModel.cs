using System.ComponentModel.DataAnnotations;

namespace ecommerce_pastry.Models
{
    public class CheckoutViewModel
    {
        [Required]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [Phone]
        public string PhoneNumber { get; set; } = string.Empty;

        [Required]
        public string Address { get; set; } = string.Empty;

        public List<Product> CartItems { get; set; } = new();
    }
}
